simpleIntegrate2D
=================

Introduction.
-------------

The suite of simpleNMR tools now includes an integration tool for
integrating 2D spectra. It works only after the peaks have been peak
picked in the 2-D spectrum.

How it works.
-------------

First peak pick all the peaks in the 2-D spectrum either manually or by
using the simpleNMR 2D peak picking tool. Then click the simpleIntegrate
icon and for all the peaks that have been picked an integral will be
created.
