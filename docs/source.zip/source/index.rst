.. simpleNMR documentation master file, created by
   sphinx-quickstart on Sun Feb  9 17:37:18 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to simpleNMR's documentation!
=====================================

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   mnovaInstallation/mnovaInstallation
   dataPreparation/dataPreparation
   structures/structures
   simplePeakPick/simplePeakPick
   simplePREDICT/simplePREDICT
   simpleHTMLGUI/simpleHTMLGUI
   simpleASSIGN/simpleASSIGN
   simpleREPORT/simpleREPORT
   


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
